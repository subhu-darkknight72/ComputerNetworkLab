#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _POSIX_SOURCE
#include <unistd.h>

int main(){
    char buf[51];
    char loc[201];
    // if(getcwd(buf, sizeof(buf))==NULL)
    //     perror("getcwd() error\n");
    // else
    //     printf("pwd: %s\n", buf);

    // chdir("..");

    // if(getcwd(buf, sizeof(buf))==NULL)
    //     perror("getcwd() error\n");
    // else
    //     printf("pwd: %s\n", buf);

    char cmd[5];
	scanf("%s",cmd);
	strcpy(buf,cmd);
    printf("%s\n",cmd);

	int flag = 0;
	for(int i=0; i<4 && flag==0; i++){
		scanf("%50s",buf);
		printf("%ld, %s\n",strlen(buf), buf);
		// send(sockfd, buf, strlen(buf) + 1, 0);

		if(strlen(buf)<50){
            flag=1;
            // printf("working...\n");
        }
		
        strcat(loc,buf);
	}
    printf("%s",loc);
    printf("\n");
	// strcpy(buf,"end");
	// send(sockfd, buf, strlen(buf) + 1, 0);
	// printf("%s\n",buf);
	
    return 0;
}